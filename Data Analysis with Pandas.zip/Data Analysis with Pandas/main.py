import pandas as pd

data = pd.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")

FurColor = data["Primary Fur Color"]
Fur_distinct = FurColor.unique()
Fur_list = []
Count_list = []
acc_dict = {}

for fur in Fur_distinct:
    if fur not in ['Gray', 'Black', 'Cinnamon']:
        continue

    Fur_list.append(fur)
    Count_list.append(len(data[FurColor == f"{fur}"]))

acc_dict["Fur Color"] = Fur_list
acc_dict["Count"] = Count_list

df = pd.DataFrame(acc_dict)
df.to_csv("Squirrel_Count_Per_Fur_Color.csv")